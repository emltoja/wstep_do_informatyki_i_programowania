# Zadanie 7     Lista 2

# Funkcja zwracająca listę n kolejnych wyrazów ciągu Fibonnaciego
def fib_list(n):
    result = []
    for i in range(n):
        result.append(fib(i))
    return result

# Funkcja obliczająca n-ty wyraz ciągu Fibonnaciego
def fib(n):
    if n == 0 or n == 1:
        return n
    else:
        return fib(n - 1) + fib(n - 2)
    

print(fib_list(8))
